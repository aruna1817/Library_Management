import logo from './logo.svg';
import './App.css';
import LoginForm from './Components/Login';
import 'bootstrap/dist/css/bootstrap.min.css';
import RegistrationForm from './Components/RegistrationForm';
import{BrowserRouter as Router,Route,Routes} from 'react-router-dom';
import AdminPage from './Components/Admin';
import UserPage from './Components/User';


function App() {
  return (
    <div>
    <Router>
      <Routes>
      
      <Route path="/" element={<LoginForm/>}/>
      <Route path="/register" element={<RegistrationForm/>}/>
      <Route path="/admin" element={<AdminPage/>}/>
      <Route path="/user" element={<UserPage/>}/>
    </Routes>
    
    </Router>
    </div>
  );
}

export default App;
