import React, { useState, useEffect } from 'react';
import { Table, Button, Modal, Form } from 'react-bootstrap';
import axios from 'axios';
const AdminPage = () => {
  const [books, setBooks] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [newBook, setNewBook] = useState({
    id: '',
    name: '',
    author: '',
    editions: '',
    quantity: ''
  });
  // const [books, setBooks] = useState([
  //   { id: 1, name: 'Book 1', author: 'Author 1', editions: 'First Edition', quantity: 10 },
  //   { id: 2, name: 'Book 2', author: 'Author 2', editions: 'Second Edition', quantity: 15 },
   
  // ]);
 
  const handleCloseModal = () => setShowModal(false);
 
  const handleShowModal = () => setShowModal(true);
   useEffect(() => {
    axios.get('http://localhost:8083/admin/getAllBooks')
      .then(response => setBooks(response.data))
      .catch(error => console.error('There was an error fetching the books!', error));
  }, []);
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewBook({ ...newBook, [name]: value });
  };
  const handleUpdateQuantity=(id,change)=>{
    const bookIndex=books.findIndex((book)=>book.id===id)
if(bookIndex!==-1)
{
    const updatedBooks=[...books];
    updatedBooks[bookIndex].quantity=parseInt(updatedBooks[bookIndex].quantity,10)+change;
    setBooks(updatedBooks);
}
};

const handleDeleteBook=(id)=>{
    const updatedbooks=books.filter((book)=>
    book.id!==id);
    setBooks(updatedbooks);
}
 
const handleAddBook = (e) => {
      e.preventDefault();
      axios.post('http://localhost:8083/admin/addBook', newBook)
        .then(response => {
          setBooks([...books, { ...newBook, id: response.data.id }]);
          setShowModal(false);
          setNewBook({
            id: '',
            name: '',
            author: '',
            editions: '',
            quantity: ''
          });
        })
        .catch(error => console.error('There was an error adding the book!', error));
  
 
    // Generate a unique ID for the new book (optional, can be handled by backend/database)
    const id = books.length + 1;
 
    // Create a new book object
    const bookToAdd = { id, ...newBook };
 
    // Add the new book to the books state
    setBooks([...books, bookToAdd]);
 
    // Close the modal
    setShowModal(false);
    //setShowelement(false);
  };
 
  return (
    <div className='text-center'>
       { 
       <div> 
      <h2>Book Details</h2>
      <Button onClick={handleShowModal} variant="success" style={{textAlign:'center',marginBottom:'30px'}}>Add Book</Button>
 
      {/* Modal for adding a new book */}
      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Add New Book</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSublmit={handleAddBook}>
          <Form.Group controlId="formId">
              <Form.Label>Book_id</Form.Label>
              <Form.Control type="number" placeholder="Enter book_id" name="id" value={newBook.id} onChange={handleInputChange} />
              </Form.Group> 
<Form.Group controlId="formName">
              <Form.Label>Name</Form.Label>
              <Form.Control type="text" placeholder='Enter name' name="name" value={newBook.name} onChange={handleInputChange} />
</Form.Group>
<Form.Group controlId="formAuthor">
              <Form.Label>Author</Form.Label>
              <Form.Control type="text" placeholder="Enter author" name="author" value={newBook.author} onChange={handleInputChange} />
</Form.Group>
<Form.Group controlId="formEditions">
              <Form.Label>Editions</Form.Label>
              <Form.Control type="text" placeholder="Enter editions" name="editions" value={newBook.editions} onChange={handleInputChange} />
</Form.Group>
<Form.Group controlId="formQuantity">
              <Form.Label>Quantity</Form.Label>
              <Form.Control type="number" placeholder="Enter quantity" name="quantity" value={newBook.quantity} onChange={handleInputChange} />
</Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>Close</Button>
          <Button variant="primary" onClick={handleAddBook} >Add Book</Button>
        </Modal.Footer>
      </Modal>
     
      {/* Table for displaying books */}
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Book_ID</th>
            <th>Name</th>
            <th>Author</th>
            <th>Editions</th>
            <th>Quantity</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr key={book.id}>
             <td>{book.id}</td>
            <td>{book.name}</td>
              <td>{book.author}</td>
              <td>{book.editions}</td>
              <td>{book.quantity}</td>
              <td>
<Button onClick={()=>handleUpdateQuantity(book.id,1)} variant="info">+</Button>
<Button onClick={()=>handleUpdateQuantity(book.id, -1)} variant="info">-</Button>
<Button onClick={()=>handleDeleteBook(book.id)} variant="danger">Delete</Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
     </div>
}
    </div>
  );
};
 
export default AdminPage

// import React, { useState, useEffect } from 'react'; 
// import { Table, Button, Modal, Form, Container } from 'react-bootstrap';
// import axios from 'axios';

// const AdminPage = () => {
//   const [books, setBooks] = useState([]);
//   const [showModal, setShowModal] = useState(false);
//   const [newBook, setNewBook] = useState({
//     id: '',
//     name: '',
//     author: '',
//     editions: '',
//     quantity: ''
//   });

//   useEffect(() => {
//     axios.get('http://localhost:8083/admin/getAllBooks')
//       .then(response => setBooks(response.data))
//       .catch(error => console.error('There was an error fetching the books!', error));
//   }, []);

//   const handleShowModal = () => setShowModal(true);
//   const handleCloseModal = () => setShowModal(false);

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setNewBook({ ...newBook, [name]: value });
//   };

//   const handleAddBook = (e) => {
//     e.preventDefault();
//     axios.post('http://localhost:8083/admin/addBook', newBook)
//       .then(response => {
//         setBooks([...books, { ...newBook, id: response.data.id }]);
//         setShowModal(false);
//         setNewBook({
//           id: '',
//           name: '',
//           author: '',
//           editions: '',
//           quantity: ''
//         });
//       })
//       .catch(error => console.error('There was an error adding the book!', error));
//   };

//   const handleUpdateQuantity = (id, quantity) => {
//     axios.put(`http://localhost:8083/admin/updateBookQuantity/${id}`,null,{params:{quantity}})
//       .then(response => {
//         setBooks(books.map(book =>
//           book.id === id ?response.data: book));
//       })
//       .catch(error => console.error('There was an error updating the book quantity!', error));
//   };

//   const increaseQuantity = (id, currentQuantity) => {
//     handleUpdateQuantity(id, currentQuantity + 1);
//   };

//   const decreaseQuantity = (id, currentQuantity) => {
//     if (currentQuantity > 0) {
//       handleUpdateQuantity(id, currentQuantity - 1);
//     }
//   };

//   const handleDeleteBook = (id) => {
//     axios.delete(`http://localhost:8083/admin/deleteBook/${id}`)
//       .then(response => {
//         setBooks(books.filter(book => book.id !== id));
//       })
//       .catch(error => console.error('There was an error deleting the book!', error));
//   };

//   return (
//     <Container>
//       <div className="text-center mb-4">
//         <h2>Admin Page</h2>
//         <Button variant="success" onClick={handleShowModal}>Add Book</Button>
//       </div>
//       <Table striped bordered hover>
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Name</th>
//             <th>Author</th>
//             <th>Editions</th>
//             <th>Quantity</th>
//             <th>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {books.map((book) => (
//             <tr key={book.id}>
//               <td>{book.id}</td>
//               <td>{book.name}</td>
//               <td>{book.author}</td>
//               <td>{book.editions}</td>
//               <td>{book.quantity}</td>
//               <td>
//                 <Button variant="secondary" onClick={() => decreaseQuantity(book.id, book.quantity)}>-</Button>
//                 <Button variant="secondary" onClick={() => increaseQuantity(book.id, book.quantity)}>+</Button>
//                 <Button variant="danger" onClick={() => handleDeleteBook(book.id)}>Delete Book</Button>
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </Table>

//       {/* Modal for adding a new book */}
//       <Modal show={showModal} onHide={handleCloseModal}>
//         <Modal.Header closeButton>
//           <Modal.Title>Add New Book</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           <Form onSubmit={handleAddBook}>
//             <Form.Group controlId="formId">
//               <Form.Label>ID</Form.Label>
//               <Form.Control type="number" name="id" value={newBook.id} onChange={handleInputChange} required />
//             </Form.Group>
//             <Form.Group controlId="formName">
//               <Form.Label>Name</Form.Label>
//               <Form.Control type="text" name="name" value={newBook.name} onChange={handleInputChange} required />
//             </Form.Group>
//             <Form.Group controlId="formAuthor">
//               <Form.Label>Author</Form.Label>
//               <Form.Control type="text" name="author" value={newBook.author} onChange={handleInputChange} required />
//             </Form.Group>
//             <Form.Group controlId="formEditions">
//               <Form.Label>Editions</Form.Label>
//               <Form.Control type="text" name="editions" value={newBook.editions} onChange={handleInputChange} required />
//             </Form.Group>
//             <Form.Group controlId="formQuantity">
//               <Form.Label>Quantity</Form.Label>
//               <Form.Control type="number" name="quantity" value={newBook.quantity} onChange={handleInputChange} required />
//             </Form.Group>
//             <Button variant="primary" type="submit">
//               Add Book
//             </Button>
//           </Form>
//         </Modal.Body>
//       </Modal>
//     </Container>
//   );
// };

// export default AdminPage;
