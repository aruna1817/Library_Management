import React, { useState } from 'react';
import {  Link } from 'react-router-dom';
import {useNavigate} from  "react-router-dom";
import {Container,Form, Button,Card } from 'react-bootstrap';
 
const LoginForm = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const history=useNavigate();
 
  const handleLogin = (e) => {
    e.preventDefault();
       
    if(username==='admin'&& password==='admin')
    {
        history('/admin');
    }
    else if(username!=='admin')
    {
        history('/user');
    }
    else
    {
    history('/register');
    }
  };
  return (
    <Container>
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
      <Card className="col-md-6 p-4">
        
          <h2 className="text-center">Login</h2>
          <Form onSubmit={handleLogin}>
<Form.Group controlId="username">
              <Form.Label>Username</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
</Form.Group>
 
<Form.Group controlId="password">
              <Form.Label>Password</Form.Label>
              <Form.Control
                type="password"
                placeholder="Enter password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
</Form.Group>
 
            <div className="text-center" style={{marginTop:10}}>
              <Button variant="primary" type="submit">
                Login
              </Button>
            </div>
          </Form>
          <div className="text-center mt-3">
            <Link to="/register">Don't have an account? Register here.</Link>
          </div>
        
        </Card>
      </div>
    </Container>
  );
};
           
   
  

export default LoginForm;

