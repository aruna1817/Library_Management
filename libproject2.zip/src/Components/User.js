import React, { useState } from 'react';
import { Table, Button, Modal } from 'react-bootstrap';
 
const UserPage = ({ books, onCheckout }) => {
  const [selectedBooks, setSelectedBooks] = useState([]);
  const [showModal, setShowModal] = useState(false);
 
  const handleBookClick = (book) => {
if (selectedBooks.length < 3 && !selectedBooks.some(selectedBook => selectedBook.id === book.id)) {
      setSelectedBooks([...selectedBooks, book]);
    } else {
      alert('You can only select up to 3 different books.');
    }
  };
 
  const handleCheckout = () => {
    if (selectedBooks.length === 3) {
      // Check if there are any duplicate IDs
const uniqueBookIds = new Set(selectedBooks.map(book => book.id));
      if (uniqueBookIds.size === selectedBooks.length) {
        // Perform checkout
        onCheckout(selectedBooks);
        setShowModal(true);
        setSelectedBooks([]);
      } else {
        alert('Duplicate book IDs detected. Please select different books.');
      }
    } else {
      alert('Please select exactly 3 different books.');
    }
  };
 
  const handleCloseModal = () => setShowModal(false);
 
  return (
    <div className='text-center'>
      <h2>Book Details</h2>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Book_ID</th>
            <th>Name</th>
            <th>Author</th>
            <th>Editions</th>
            <th>Quantity</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
             <tr key={book.id}onClick={() => handleBookClick(book)}>
              <td>{book.id}</td>
               <td>{book.name}</td>
              <td>{book.author}</td>
              <td>{book.editions}</td>
              <td>{book.quantity}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      <Button onClick={handleCheckout}>Checkout</Button>
 
      {/* Modal for checkout confirmation */}
      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Checkout Confirmation</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Your checkout was successful.
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};
 
export default UserPage;




// import React from 'react';
// import { Table, Button } from 'react-bootstrap';


// const UserPage = ({ books, handleCheckout }) => {
//   const handleCheckout=()=>{
//     onCheckedout(books);
//   };
//   return (
//     <div className='text-center'>
//       <h2>Book Details</h2>
//       <Table striped bordered hover>
//         <thead>
//           <tr>
//             <th>Book_ID</th>
//             <th>Name</th>
//             <th>Author</th>
//             <th>Editions</th>
//             <th>Quantity</th>
//             <th>Actions</th>
//           </tr>
//         </thead>
//         <tbody>
//           {
//             books.map((book) => (
//               <tr key={book.id}>
//                 <td>{book.id}</td>
//                 <td>{book.name}</td>
//                 <td>{book.author}</td>
//                 <td>{book.editions}</td>
//                 <td>{book.quantity}</td>
//                 <td>
//                   <Button onClick={() => handleCheckout(book.id)} variant="primary">Checkout</Button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </Table>
//       </div>
//     );
//   };
  
//   export default UserPage;

